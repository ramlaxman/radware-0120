x = 100

y = [10, 20, 30]


def hello(name):
    return f'Hello from a, {name}'
