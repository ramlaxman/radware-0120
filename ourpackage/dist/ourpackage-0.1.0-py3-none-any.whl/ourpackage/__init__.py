__all__ = []  # whoever does from import *

from . import b
from .a import x, y
print("Hello from mypackage.__init__!")
