# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ourpackage']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'ourpackage',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Reuven M. Lerner',
    'author_email': 'reuven@lerner.co.il',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
